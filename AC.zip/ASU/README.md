![Python|2.7](https://img.shields.io/badge/Python-2.7-blue.svg)
<div <img src ="https://github.com/LOoLzeC/ASU/blob/master/raw/snake.png"/><br></div>
<br><h1>ASU Toolkit Was Release Again In 7mei 2019</h1><br><h3> Facebook  Hacking Tool</h3><br>
<img src="https://github.com/LOoLzeC/ASU/blob/master/raw/IMG-20190405-WA0003.jpg"/>
<br><br>
<h3>Installing</h3><br>
$ pkg install git<br>
$ git clone https://github.com/LOoLzeC/ASU<br>
$ cd ASU<br>
$ bash install.sh<br><br>
<a href ="https://mbasic.facebook.com/achmad.luthfi.hadi.3">ask me on facebook</a>
 
